package BoardPKG;

public class InvalidActionException extends Exception {
    public InvalidActionException() {
        super();
    }
    public InvalidActionException(String s) {
        super(s);
    }
}
