package Client;

public class Const {
    public static final int N_ITER = 10;
}
