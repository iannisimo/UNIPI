package Server;

public class Const {
    public static final int INTERVAL = 1000;
}
