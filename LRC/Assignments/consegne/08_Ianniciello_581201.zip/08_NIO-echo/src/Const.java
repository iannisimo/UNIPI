public class Const {
    public static final int DEFAULT_PORT = 2020;
    public static final String DEBUG_ADDRESS = "127.0.0.1";
    public static final int BUF_SIZE = 10;
    public static final byte[] RESP_HEADER = "Echoed by server: ".getBytes();
}