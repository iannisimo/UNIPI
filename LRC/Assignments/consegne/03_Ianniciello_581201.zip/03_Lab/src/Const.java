package src;

public class Const {

    public static final int ARGS = 3;

    public static final int NUM_PC = 20;

    public static final int MAX_USAGE_TIME = 1000;
    public static final int MAX_PAUSE_TIME = 500;

    public static final int MIN_ACCESSES = 1;
    public static final int MAX_ACCESSES = 5;

}
