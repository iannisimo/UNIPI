package Congress.Common;

public class Const {
    public static final String REG_NAME = "CONGRESS-SERVER";
}
