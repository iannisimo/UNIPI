package Congress.Server;

public class Const {
    public static final int DAYS = 3;
    public static final int SESSIONS_PER_DAY = 12;
    public static final int MAX_PER_SESSION = 5;
}
