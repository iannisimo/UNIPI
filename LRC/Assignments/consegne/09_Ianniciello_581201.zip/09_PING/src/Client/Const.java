package Client;

public class Const {
    public static final int REQNO = 10;
}
