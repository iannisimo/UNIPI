package Server;

public class Const {
    public static final int BUF_SZ = 512;
    public static final int MAX_SLEEP = 1000;
}
