#!/bin/bash

java -jar out/artifacts/server_jar/server.jar "$@"
